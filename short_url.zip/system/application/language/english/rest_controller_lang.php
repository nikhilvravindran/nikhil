<?php

$lang[' text_rest_invalid_api_key'] = 'Invalid API key 5S ';

$lang['text_rest_invalid_|credentials ' ] = 'Invalid credentials';

$lang['text_rest_ip_denied '] = 'IP denied ';

$lang['text_rest_ip_unauthorized ' ]= ' IP unauthorized' ;

$lang['text_rest_unauthorized ' ] = ' Unauthorized';

$lang[' text_rest_ajax_only']= ' Ajax requested are allowed only';

$lang[' text_rest_api_key_unauthorized']= ' This API key does not have access to the requested controller';

$lang[' text_rest_api_key_permission']= 'This API key does not have enough permission';

$lang['text_rest_api_key_time_limit']= ' This API have reached the time limit for this method';

$lang['text_rest_unknown_method ']= ' Unknown method';

$lang['text_rest_unsupported']= ' Unsupported protocols';

?>